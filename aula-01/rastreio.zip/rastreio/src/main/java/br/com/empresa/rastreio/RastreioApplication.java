package br.com.empresa.rastreio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RastreioApplication {

	public static void main(String[] args) {
		SpringApplication.run(RastreioApplication.class, args);
	}

}
