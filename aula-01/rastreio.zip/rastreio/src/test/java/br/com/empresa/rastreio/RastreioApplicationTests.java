package br.com.empresa.rastreio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RastreioApplicationTests {

	@Test
	void contextLoads() {
	}

}
